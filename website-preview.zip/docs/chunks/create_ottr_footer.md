
<br>
<br>
<center>
<a href="https://www.ottrproject.org/">
  <img src="css/images/basic_otter_water.png" width = 40%>
</a>
</center>

<div class = "authors"> **Authors**: {AUTHORS} 
[OTTR](https://www.ottrproject.org/) was created and or is maintained by the following team: Candace Savonen, Carrie Wright, Kate Isaac, Ava Hoffman, Katherine Cox, Federick Tan, John Muschelli, Howard Baek, and Jeffrey Leek.  
</div>
