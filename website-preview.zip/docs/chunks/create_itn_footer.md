
<hr>

<center>
<a href="https://www.itcrtraining.org/">
  <img src="css/images/ITN_logo.png" width = 30%>
</a>
</center>

<div class = "authors"> **Authors**: {AUTHORS}
</div>
