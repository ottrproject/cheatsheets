
<div class = "header_box">
<u>{TITLE}</u><br><span style = "color:#14395f;"> {SUBTITLE} </span>
</div>

 <div class = "png_button"><a href="{PATH_TO_PNG}">Download cheatsheet</a></div>

 <div class = "time">**Last updated: `r format(Sys.time(), '%B %d, %Y')`** </div>
