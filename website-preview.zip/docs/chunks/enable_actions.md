## Enable workflow actions

<input type="checkbox">  In your OTTR repository, go to **Settings** in the top navigation tabs `r config::get("settings")`

<input type="checkbox">  Go to **Actions** (General) in the side navigation `r config::get("actions")`

<input type="checkbox">   Under **Workflow permissions**

1. <input type="checkbox"> Select **Read and write permissions**

2. <input type="checkbox">  Check **Allow GitHub Actions to create and approve pull requests**

3. <input type="checkbox">  Click **Save**
