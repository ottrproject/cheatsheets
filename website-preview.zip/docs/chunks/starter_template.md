
## Create your own repository from the [{TEMPLATE_NAME}]({TEMPLATE_URL}) template

<input type="checkbox">  In the upper right, _click on_: <div class = "github_button"> <a href="https://github.com/new?template_name={TEMPLATE_NAME}"> Use this template</a></div>

<input type="checkbox">  Set your repo to "**Public**"
