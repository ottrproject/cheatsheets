## Set up GitHub Pages

<input type="checkbox"> In your OTTR repository, go to Settings in the top navigation tabs `r config::get("settings")`

<input type="checkbox"> Go to **Pages** in the side navigation `r config::get("pages")`

<input type="checkbox"> In the **Build and deployment section**

  1. <input type="checkbox"> Under **Source**, select **Deploy from a branch**
  2. <input type="checkbox"> Under **Branch**, pick **main** and choose **/docs**, and click **Save**

<input type="checkbox"> at the bottom of the page, check **Enforce HTTPS**
