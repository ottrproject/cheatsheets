
<div class = "header_box">
<u>Social Media</u><br><span style = "color:#14395f;"> Tips and Tricks </span>
</div>

 <div class = "png_button"><a href="https://raw.githubusercontent.com/ottrproject/cheatsheets/refs/heads/main/pngs/social_media.png">Download cheatsheet</a></div>

 <div class = "time">**Last updated: `r format(Sys.time(), '%B %d, %Y')`** </div>
