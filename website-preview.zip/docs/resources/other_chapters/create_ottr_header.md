
<div class = "header_box">
<u>OTTR Website</u><br><span style = "color:#986753;"> Set Up </span>
</div>

 <div class = "png_button"><a href="https://github.com/ottrproject/cheatsheets/blob/main/pngs/ottr_website.png?raw=true">Download cheatsheet</a></div>

 <div class = "time">**Last updated: `r format(Sys.time(), '%B %d, %Y')`** </div>
