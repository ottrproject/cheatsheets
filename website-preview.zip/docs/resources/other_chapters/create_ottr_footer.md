
<br>
<br>
<center>
<a href="https://www.ottrproject.org/">
  <img src="css/images/basic_otter_water.png" width = 40%>
</a>
</center>

<div class = "authors"> **Authors**: Kate Isaac wrote the content and created the original styling, Carrie Wright did the css styling and Carrie Wright and Candace Savonen did the publishing engineering for the cheatsheet. 
[OTTR](https://www.ottrproject.org/) was created and or is maintained by the following team: Candace Savonen, Carrie Wright, Kate Isaac, Ava Hoffman, Katherine Cox, Federick Tan, John Muschelli, Howard Baek, and Jeffrey Leek.  
</div>
