
## Create your own repository from the [OTTR_Template_Website](https://github.com/ottrproject/OTTR_Template_Website) template

<input type="checkbox">  In the upper right, _click on_: <div class = "github_button"> <a href="https://github.com/new?template_name=OTTR_Template_Website"> Use this template</a></div>

<input type="checkbox">  Set your repo to "**Public**"
