
<hr>

<center>
<a href="https://www.itcrtraining.org/">
  <img src="css/images/ITN_logo.png" width = 30%>
</a>
</center>

<div class = "authors"> **Authors**: Content for this cheatsheet came from Kate Isaac, Carrie Wright, and Sean Davis.It was summarized and formatted by Carrie Wright. Icons from https://www.iconpacks.net. The cheatsheet was also inspired by this article: https://pmc.ncbi.nlm.nih.gov/articles/PMC2738972/ and ideas from AI: https://www.perplexity.ai/search/i-m-organizing-a-scientific-me-b5m7ym8jTBOl2MjdMhLlRw
</div>
