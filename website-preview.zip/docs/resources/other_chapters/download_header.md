<link rel="shortcut icon" href="css/images/ITN_favicon.ico" />
 <!--- go to https://favicon.io/favicon-converter/ to upload an image to make a new favicon.io. You will need to replace the current favicon.io image with the one in the downloaded directory from the website. The current image is in the resources/images/ directory --->


 <div class = "github_button"><a href="https://raw.githubusercontent.com/ottrproject/cheatsheets/refs/heads/main/pngs/ottr_quarto_course.png">Download cheatsheet</a></div>
